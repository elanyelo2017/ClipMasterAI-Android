package com.clipmasterai

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.graphics.Bitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class TimedFaceCrop(
    val timeMs: Long,
    val result: FaceFrameResult
)

data class VideoFaceScan(
    val durationMs: Long,
    val sampledFrames: Int,
    val framesWithFaces: Int,
    val crops: List<TimedFaceCrop>
)

/**
 * Extrae fotogramas del video localmente y los analiza con ML Kit.
 * Muestrea a intervalos configurables para limitar CPU y memoria en móviles modestos.
 */
class VideoFaceScanRepository {

    suspend fun scan(
        context: Context,
        uri: Uri,
        intervalMs: Long = 1_000L,
        maxFrames: Int = 120,
        onProgress: (Int, Int) -> Unit = { _, _ -> }
    ): VideoFaceScan = withContext(Dispatchers.IO) {
        require(intervalMs >= 250L) { "El intervalo mínimo es 250 ms." }
        require(maxFrames in 1..600) { "El máximo de fotogramas debe estar entre 1 y 600." }

        val retriever = MediaMetadataRetriever()
        val analyzer = FaceTrackingAnalyzer()
        try {
            context.contentResolver.openFileDescriptor(uri, "r")?.use { descriptor ->
                retriever.setDataSource(descriptor.fileDescriptor)
                val duration = retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_DURATION
                )?.toLongOrNull() ?: 0L

                if (duration <= 0L) error("No se pudo leer la duración del video.")

                val times = generateSequence(0L) { previous ->
                    if (previous + intervalMs < duration) previous + intervalMs else null
                }.take(maxFrames).toList()

                val results = ArrayList<TimedFaceCrop>(times.size)
                times.forEachIndexed { index, timeMs ->
                    val bitmap: Bitmap? = retriever.getFrameAtTime(
                        timeMs * 1_000L,
                        MediaMetadataRetriever.OPTION_CLOSEST
                    )
                    if (bitmap != null) {
                        try {
                            val result = analyzer.analyzeFrameAwait(bitmap)
                            results += TimedFaceCrop(timeMs, result)
                        } finally {
                            bitmap.recycle()
                        }
                    }
                    onProgress(index + 1, times.size)
                }

                VideoFaceScan(
                    durationMs = duration,
                    sampledFrames = results.size,
                    framesWithFaces = results.count { it.result.faceCount > 0 },
                    crops = results
                )
            } ?: error("Android no pudo abrir el video seleccionado.")
        } finally {
            analyzer.close()
            retriever.release()
        }
    }
}

private suspend fun FaceTrackingAnalyzer.analyzeFrameAwait(bitmap: Bitmap): FaceFrameResult =
    suspendCancellableCoroutine { continuation ->
        analyzeFrame(
            bitmap = bitmap,
            onResult = { result ->
                if (continuation.isActive) continuation.resume(result)
            },
            onError = { error ->
                if (continuation.isActive) continuation.resumeWithException(error)
            }
        )
    }
