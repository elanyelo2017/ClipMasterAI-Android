package com.clipmasterai

import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Exporta hasta 10 rangos temporales como MP4 independientes. */
@UnstableApi
class ClipBatchExporter(
    context: Context,
    private val onProgress: (Int, Int, String) -> Unit,
    private val onCompleted: (List<File>) -> Unit,
    private val onError: (String, List<File>) -> Unit
) {
    private val appContext = context.applicationContext
    private var transformer: Transformer? = null
    private var cancelled = false
    private val outputs = mutableListOf<File>()
    private var clips: List<ClipCandidate> = emptyList()
    private var source: Uri? = null
    private var index = 0
    private lateinit var outputDir: File
    private val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    fun export(uri: Uri, candidates: List<ClipCandidate>) {
        val valid = candidates.filter { it.startSeconds >= 0 && it.endSeconds > it.startSeconds }.take(10)
        if (valid.isEmpty()) {
            onError("No hay clips válidos para exportar.", emptyList())
            return
        }
        outputDir = appContext.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: appContext.filesDir
        if (!outputDir.exists() && !outputDir.mkdirs()) {
            onError("No se pudo crear la carpeta de exportación.", emptyList())
            return
        }
        source = uri
        clips = valid
        outputs.clear()
        index = 0
        cancelled = false
        exportNext()
    }

    private fun exportNext() {
        if (cancelled) return
        if (index >= clips.size) {
            transformer = null
            onCompleted(outputs.toList())
            return
        }
        val clip = clips[index]
        val output = File(outputDir, "ClipMasterAI_${stamp}_clip${index + 1}.mp4")
        val clipping = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(clip.startSeconds * 1000L)
            .setEndPositionMs(clip.endSeconds * 1000L)
            .build()
        val item = MediaItem.Builder().setUri(source!!).setClippingConfiguration(clipping).build()
        val crop = Presentation.createForAspectRatio(9f / 16f, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
        val edited = EditedMediaItem.Builder(item)
            .setEffects(Effects(emptyList(), listOf(crop)))
            .build()
        onProgress(index + 1, clips.size, "Exportando clip ${index + 1} de ${clips.size}…")
        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                outputs.add(output)
                transformer = null
                index++
                exportNext()
            }
            override fun onError(composition: androidx.media3.transformer.Composition, exportResult: ExportResult, exportException: ExportException) {
                transformer = null
                output.delete()
                onError("Falló el clip ${index + 1}: ${exportException.message ?: "error de exportación"}", outputs.toList())
            }
        }
        try {
            transformer = Transformer.Builder(appContext).addListener(listener).build()
            transformer?.start(edited, output.absolutePath)
        } catch (e: Exception) {
            transformer = null
            output.delete()
            onError("No se pudo iniciar el clip ${index + 1}: ${e.message ?: "error"}", outputs.toList())
        }
    }

    fun cancel() {
        cancelled = true
        transformer?.cancel()
        transformer = null
    }
}
