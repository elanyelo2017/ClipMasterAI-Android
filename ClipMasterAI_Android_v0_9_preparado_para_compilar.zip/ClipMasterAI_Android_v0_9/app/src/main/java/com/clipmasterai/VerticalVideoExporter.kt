package com.clipmasterai

import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Exportación MP4 vertical 9:16 mediante Media3 Transformer.
 * Mantiene el audio de la fuente y aplica un recorte central para llenar 9:16.
 *
 * Nota: en v0.5 este exportador todavía no aplica la trayectoria facial dinámica
 * calculada por FaceTrackingAnalyzer; esa integración queda para la siguiente fase.
 */
@UnstableApi
class VerticalVideoExporter(
    context: Context,
    private val completionCallback: (File) -> Unit,
    private val errorCallback: (String) -> Unit,
    private val onProgress: (Int) -> Unit = {}
) {
    private val appContext = context.applicationContext
    private var transformer: Transformer? = null

    fun export(input: Uri) {
        val moviesDir = appContext.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
            ?: appContext.filesDir
        if (!moviesDir.exists() && !moviesDir.mkdirs()) {
            errorCallback("No se pudo crear la carpeta de exportación.")
            return
        }

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val output = File(moviesDir, "ClipMasterAI_$stamp.mp4")
        val mediaItem = MediaItem.fromUri(input)

        val cropToVertical = Presentation.createForAspectRatio(
            9f / 16f,
            Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
        )
        val editedItem = EditedMediaItem.Builder(mediaItem)
            .setEffects(Effects(emptyList(), listOf(cropToVertical)))
            .build()

        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: androidx.media3.transformer.Composition,
                                     exportResult: ExportResult) {
                transformer = null
                onProgress(100)
                completionCallback(output)
            }

            override fun onError(composition: androidx.media3.transformer.Composition,
                                 exportResult: ExportResult,
                                 exportException: ExportException) {
                transformer = null
                output.delete()
                errorCallback(exportException.message ?: "Error al exportar el video.")
            }
        }

        transformer = Transformer.Builder(appContext)
            .addListener(listener)
            .build()
        try {
            transformer?.start(editedItem, output.absolutePath)
        } catch (error: Exception) {
            transformer = null
            output.delete()
            errorCallback(error.message ?: "No se pudo iniciar la exportación.")
        }
    }

    fun cancel() {
        transformer?.cancel()
        transformer = null
    }
}
