package com.clipmasterai

/**
 * Contract for the on-device ASR module. The implementation will use a bundled/downloaded
 * sherpa-onnx or whisper.cpp model and must never send audio to a server.
 * This interface is deliberately not backed by a fake implementation.
 */
interface LocalTranscriptionEngine {
    suspend fun transcribe(wavFilePath: String): List<TimedSentence>
}

/** Audio must be mono PCM 16 kHz for the selected ASR model. */
data class AudioInputSpec(
    val sampleRateHz: Int = 16_000,
    val channels: Int = 1,
    val encoding: String = "PCM_16BIT"
)
