package com.clipmasterai

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlin.math.max
import kotlin.math.min

data class CropWindow(
    val left: Int, val top: Int, val right: Int, val bottom: Int
) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top
}

data class FaceFrameResult(
    val crop: CropWindow,
    val faceCount: Int,
    val trackedFaceId: Int?
)

/**
 * Analiza fotogramas Bitmap en orden temporal. El llamador del pipeline de
 * video debe muestrear los frames y aplicar el CropWindow durante la exportación.
 */
class FaceTrackingAnalyzer(
    private val smoothing: Float = 0.28f,
    private val verticalBias: Float = 0.42f
) : AutoCloseable {

    private val detector: FaceDetector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .enableTracking()
            .setMinFaceSize(0.08f)
            .build()
    )

    private var smoothedCenterX: Float? = null
    private var smoothedCenterY: Float? = null
    private var lastTrackingId: Int? = null

    fun analyzeFrame(
        bitmap: Bitmap,
        onResult: (FaceFrameResult) -> Unit,
        onError: (Exception) -> Unit
    ) {
        detector.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { faces ->
                val face = chooseFace(faces)
                if (face == null) {
                    onResult(FaceFrameResult(centeredCrop(bitmap.width, bitmap.height), 0, null))
                } else {
                    val bounds = face.boundingBox
                    val targetX = bounds.exactCenterX()
                    val targetY = bounds.exactCenterY() - bounds.height() * 0.18f
                    val x = smooth(smoothedCenterX, targetX).also { smoothedCenterX = it }
                    val y = smooth(smoothedCenterY, targetY).also { smoothedCenterY = it }
                    lastTrackingId = face.trackingId
                    onResult(
                        FaceFrameResult(
                            faceCenteredCrop(bitmap.width, bitmap.height, x, y),
                            faces.size,
                            face.trackingId
                        )
                    )
                }
            }
            .addOnFailureListener { onError(it) }
    }

    private fun chooseFace(faces: List<Face>): Face? {
        if (faces.isEmpty()) return null
        val previousId = lastTrackingId
        if (previousId != null) faces.firstOrNull { it.trackingId == previousId }?.let { return it }
        return faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }
    }

    private fun smooth(previous: Float?, current: Float): Float =
        if (previous == null) current
        else previous + (current - previous) * smoothing.coerceIn(0.05f, 1f)

    private fun faceCenteredCrop(width: Int, height: Int, centerX: Float, centerY: Float): CropWindow {
        val (cropWidth, cropHeight) = cropSize(width, height)
        val left = (centerX - cropWidth / 2f).toInt().coerceIn(0, width - cropWidth)
        val top = (centerY - cropHeight * verticalBias).toInt().coerceIn(0, height - cropHeight)
        return CropWindow(left, top, left + cropWidth, top + cropHeight)
    }

    private fun centeredCrop(width: Int, height: Int): CropWindow {
        val (cropWidth, cropHeight) = cropSize(width, height)
        val left = max(0, (width - cropWidth) / 2)
        val top = max(0, (height - cropHeight) / 2)
        return CropWindow(left, top, left + cropWidth, top + cropHeight)
    }

    private fun cropSize(width: Int, height: Int): Pair<Int, Int> =
        if (width.toFloat() / height.toFloat() > 9f / 16f) {
            height * 9 / 16 to height
        } else {
            width to (width * 16 / 9)
        }

    override fun close() {
        detector.close()
    }
}
