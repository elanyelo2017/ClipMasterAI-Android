# ClipMaster AI Android — v0.9.0

Proyecto fuente Android (Kotlin + Jetpack Compose), pensado para Android 14 y el OUKITEL G3. El procesamiento implementado se realiza en el dispositivo; no requiere cuenta ni suscripción.

## Funciones incluidas en este paquete
- Selección de videos locales mediante el selector de Android.
- Análisis local de fotogramas y detección de rostros con ML Kit (muestreo limitado para reducir consumo).
- Exportación MP4 vertical 9:16 del video seleccionado mediante Media3 Transformer.
- Exportación por lotes de hasta 10 rangos temporales válidos como MP4 independientes.
- Entrada de transcripción con marcas de tiempo en la app y puntuación heurística de frases llamativas para proponer hasta 10 momentos.
- Conservación del audio original en la exportación mediante Media3.

## Cómo introducir una transcripción
En la pantalla principal pega una frase por línea con este formato:

`00:12-00:18 | No vas a creer lo que pasó`

También admite horas: `00:01:12-00:01:18 | texto`. Pulsa **Analizar transcripción**, revisa los candidatos y luego exporta el lote. La puntuación es heurística y no equivale a una evaluación real de viralidad.

## Limitaciones conocidas (no presentadas como funciones terminadas)
- **No incluye todavía reconocimiento de voz offline**: Whisper.cpp/sherpa-onnx no está integrado. La transcripción debe pegarse manualmente.
- La selección de momentos se basa en palabras clave y signos de puntuación, no en un modelo de IA entrenado ni en análisis acústico.
- El análisis facial informa sobre rostros muestreados, pero el recorte facial dinámico aún no se aplica durante la exportación.
- No genera subtítulos quemados automáticamente.
- No publica directamente en TikTok, YouTube Shorts, Facebook Reels o Instagram.
- Este paquete es código fuente ZIP, no un APK.

## Compilar
1. Extrae el ZIP.
2. Abre la carpeta raíz `ClipMasterAI_Android_v0_9` en Android Studio.
3. Usa JDK 17 y deja que Gradle descargue dependencias.
4. Ejecuta la compilación de APK (Build > Build APK(s)).
5. Instala y prueba en el OUKITEL G3.

## Validación
Este entorno no dispone de Android SDK/Gradle configurado para compilar y probar la app. Por tanto, la versión 0.9.0 es una actualización del código fuente, pero **no se afirma que compile ni que haya sido probada en el teléfono**. Verifica Media3 Transformer, permisos de acceso a archivos, consumo de memoria y temperatura en el OUKITEL G3 antes de usarla con videos largos.

## Compilar desde el teléfono mediante GitHub Actions
Este proyecto incluye `.github/workflows/build-apk.yml` para solicitar una compilación en GitHub Actions sin instalar Android Studio en el OUKITEL G3. Necesitas una cuenta de GitHub y conexión a Internet para esta compilación:
1. Crea un repositorio nuevo en GitHub.
2. Sube el contenido de esta carpeta (no solamente el ZIP) al repositorio, conservando la carpeta `.github/workflows`.
3. En el repositorio abre **Actions** y selecciona **Build ClipMaster AI APK**.
4. Pulsa **Run workflow** y espera a que termine.
5. En la ejecución completada, descarga el artefacto **ClipMasterAI-v0.9-debug-apk**. Dentro estará `app-debug.apk`.
6. Descarga el APK en Android y permite la instalación desde esa fuente cuando el teléfono lo solicite.

La compilación remota no significa que la app haya sido probada en el OUKITEL G3. Instala primero y prueba con un video corto.
