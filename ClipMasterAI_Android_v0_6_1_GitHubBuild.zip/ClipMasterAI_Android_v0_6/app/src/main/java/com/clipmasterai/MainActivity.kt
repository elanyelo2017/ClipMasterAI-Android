package com.clipmasterai

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.text.style.TextOverflow
import androidx.media3.common.util.UnstableApi
import java.io.File
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch

data class ClipCandidate(
    val startSeconds: Int,
    val endSeconds: Int,
    val score: Int,
    val reason: String
)

class ClipViewModel : ViewModel() {
    var selectedVideo by mutableStateOf<Uri?>(null)
        private set
    var candidates by mutableStateOf<List<ClipCandidate>>(emptyList())
        private set
    var status by mutableStateOf("Selecciona un video para comenzar.")
        private set

    fun setVideo(uri: Uri) {
        selectedVideo = uri
        candidates = emptyList()
        status = "Video seleccionado. El análisis de IA se integrará en el siguiente módulo."
    }

    // MVP temporal: puntúa segmentos a partir de una transcripción proporcionada.
    // La integración Whisper debe entregar frases con marcas de tiempo a esta función.
    fun analyzeTranscript(lines: List<TimedSentence>) {
        candidates = HighlightScorer.rank(lines).take(10)
        status = if (candidates.isEmpty()) "No se encontraron momentos; prueba con otra transcripción."
                 else "Se encontraron ${candidates.size} momentos candidatos."
    }
}

data class TimedSentence(val start: Int, val end: Int, val text: String)

object HighlightScorer {
    private val hooks = listOf(
        "no vas a creer", "increíble", "secreto", "error", "nunca", "siempre",
        "por qué", "cómo", "la verdad", "importante", "sorpresa", "mejor",
        "peor", "atención", "resultado", "finalmente", "imagina"
    )

    fun rank(lines: List<TimedSentence>): List<ClipCandidate> =
        lines.mapNotNull { line ->
            val normalized = line.text.lowercase()
            val matches = hooks.count { normalized.contains(it) }
            val questionBonus = if ('?' in line.text || '¿' in line.text) 1 else 0
            val exclamationBonus = if ('!' in line.text || '¡' in line.text) 1 else 0
            val score = matches * 3 + questionBonus + exclamationBonus
            if (score < 1 || line.end <= line.start) null
            else ClipCandidate(
                startSeconds = (line.start - 8).coerceAtLeast(0),
                endSeconds = line.end + 12,
                score = score,
                reason = "Frase llamativa detectada"
            )
        }.sortedByDescending { it.score }
         .distinctBy { it.startSeconds / 15 }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ClipMasterScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
@OptIn(UnstableApi::class)
fun ClipMasterScreen(vm: ClipViewModel = viewModel()) {
    val context = LocalContext.current
    var exporting by remember { mutableStateOf(false) }
    var exportMessage by remember { mutableStateOf("") }
    var exportedFile by remember { mutableStateOf<File?>(null) }
    var exporter by remember { mutableStateOf<VerticalVideoExporter?>(null) }
    var batchExporter by remember { mutableStateOf<ClipBatchExporter?>(null) }
    var batchExporting by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var scanningFaces by remember { mutableStateOf(false) }
    var faceScanMessage by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            // Conserva permiso de lectura para acceder al video después.
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                        it, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
            }
            vm.setVideo(it)
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("ClipMaster AI") }) }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Detector inteligente de momentos", style = MaterialTheme.typography.titleLarge)
                Text("Procesamiento local · Sin suscripción · Hasta 10 clips")
                Button(onClick = { picker.launch(arrayOf("video/*")) }) {
                    Text("Seleccionar video")
                }
                vm.selectedVideo?.let { uri ->
                    Text("Video: ${uri.lastPathSegment ?: uri}")
                    Button(
                        enabled = !scanningFaces,
                        onClick = {
                            scanningFaces = true
                            faceScanMessage = "Preparando análisis local..."
                            scope.launch {
                                try {
                                    val result = VideoFaceScanRepository().scan(
                                        context = context,
                                        uri = uri,
                                        intervalMs = 1_000L,
                                        maxFrames = 120
                                    )
                                    faceScanMessage =
                                        "Análisis terminado: ${result.sampledFrames} fotogramas; " +
                                        "${result.framesWithFaces} con rostros. " +
                                        "Duración: ${formatTime((result.durationMs / 1000).toInt())}."
                                } catch (error: Exception) {
                                    faceScanMessage = "No se pudo analizar el video: ${error.message ?: "error desconocido"}"
                                } finally {
                                    scanningFaces = false
                                }
                            }
                        }
                    ) {
                        Text(if (scanningFaces) "Analizando rostros..." else "Analizar rostros y encuadre")
                    }
                    if (faceScanMessage.isNotBlank()) Text(faceScanMessage)
                    Button(
                        enabled = !exporting,
                        onClick = {
                            exporting = true
                            exportMessage = "Preparando exportación MP4 vertical..."
                            val currentExporter = VerticalVideoExporter(
                                context = context,
                                completionCallback = { file ->
                                    exporting = false
                                    exportedFile = file
                                    exportMessage = "Video exportado correctamente: ${file.name}"
                                },
                                errorCallback = { message ->
                                    exporting = false
                                    exportMessage = "No se pudo exportar: $message"
                                },
                                onProgress = { }
                            )
                            exporter = currentExporter
                            currentExporter.export(uri)
                        }
                    ) {
                        Text(if (exporting) "Exportando MP4..." else "Exportar MP4 vertical 9:16")
                    }
                    if (exportMessage.isNotBlank()) {
                        Text(exportMessage, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    }
                    exportedFile?.let { file ->
                        Text("Guardado en: ${file.parent}")
                    }
                }
                if (vm.candidates.isNotEmpty()) {
                    Button(
                        enabled = !batchExporting && !exporting,
                        onClick = {
                            val selected = vm.selectedVideo ?: return@Button
                            batchExporting = true
                            exportMessage = "Preparando exportación de clips…"
                            val batch = ClipBatchExporter(
                                context = context,
                                onProgress = { current, total, message -> exportMessage = "$message ($current/$total)" },
                                onCompleted = { files ->
                                    batchExporting = false
                                    exportMessage = "Lote terminado: ${files.size} clips guardados en Movies de ClipMaster AI."
                                },
                                onError = { message, files ->
                                    batchExporting = false
                                    exportMessage = "$message Clips completados: ${files.size}."
                                }
                            )
                            batchExporter = batch
                            batch.export(selected, vm.candidates)
                        }
                    ) {
                        Text(if (batchExporting) "Exportando clips…" else "Exportar hasta 10 clips MP4")
                    }
                }
                Text(vm.status)
                HorizontalDivider()
                Text("Momentos candidatos", style = MaterialTheme.typography.titleMedium)
                if (vm.candidates.isEmpty()) {
                    Text("Todavía no hay resultados. La transcripción local automática y el análisis del audio están en integración.")
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(vm.candidates) { clip ->
                            Card {
                                Column(Modifier.padding(12.dp)) {
                                    Text("${formatTime(clip.startSeconds)} – ${formatTime(clip.endSeconds)}")
                                    Text("Puntuación: ${clip.score}/10")
                                    Text(clip.reason)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatTime(seconds: Int): String =
    "%02d:%02d".format(seconds / 60, seconds % 60)
