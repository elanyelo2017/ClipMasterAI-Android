# ClipMaster AI Android — paquete 0.6.1 con compilación en GitHub

Este paquete parte del proyecto 0.6 recibido. Se agregó un flujo de GitHub Actions para intentar compilar un APK de depuración en la nube, sin instalar Android Studio en el OUKITEL G3.

## Compilar desde GitHub usando el teléfono

1. Crea un repositorio nuevo en GitHub (por ejemplo, `ClipMasterAI-Android`).
2. En el repositorio, pulsa **Add file → Upload files**.
3. Extrae este ZIP primero. Sube el contenido de la carpeta `ClipMasterAI_Android_v0_6` (incluida la carpeta oculta `.github`) al repositorio.
4. Confirma los cambios en la rama `main`.
5. Abre la pestaña **Actions** del repositorio.
6. Selecciona **Build Android APK** y espera a que termine.
7. Si el trabajo termina correctamente, abre la ejecución y descarga el artefacto `ClipMasterAI-debug-apk`. Dentro estará `app-debug.apk`.

## Estado real de funciones

Este paquete NO es todavía la versión funcional 0.9. Es una preparación 0.6.1 para facilitar la primera compilación verificable.

Incluye:
- Selección de video local.
- Análisis de rostros con ML Kit.
- Exportación vertical 9:16 y exportación por lotes para candidatos que ya tengan tiempos.
- Puntuador básico de frases a partir de una transcripción suministrada.

Pendiente:
- Reconocimiento de voz local real (ASR) conectado al video.
- Detección automática de momentos desde el audio/transcripción.
- Generación y quemado/exportación de subtítulos.
- Aplicación del seguimiento facial al recorte durante la exportación.
- Pruebas reales en el OUKITEL G3 y medición de memoria/temperatura.

## Importante
- El ZIP contiene código fuente, no un APK.
- La compilación de GitHub solo se considera exitosa si el flujo de Actions termina en verde y produce el artefacto APK.
- El APK `debug` sirve para pruebas; no es una versión firmada para publicar en Google Play.
- No se incluye todavía un modelo de reconocimiento de voz ni se envía audio a un servicio externo.
