# ClipMaster AI Android — v0.6.0

Proyecto fuente Android (Kotlin + Jetpack Compose), orientado al OUKITEL G3 / Android 14. Procesamiento previsto en el dispositivo, sin cuenta ni suscripción.

## Incluido en esta versión
- Selección de video local.
- Análisis de muestras de fotogramas para detectar rostros (ML Kit).
- Exportación de un video completo en MP4 vertical 9:16.
- Exportador por lotes: recibe hasta 10 rangos temporales (`ClipCandidate`) y genera un MP4 vertical independiente por rango, conservando el audio de origen.
- Los archivos se guardan en la carpeta privada de la aplicación: `Android/data/com.clipmasterai/files/Movies` (o almacenamiento privado interno si Android no ofrece la carpeta externa de la app).

## Limitaciones importantes
- **Todavía no detecta automáticamente los mejores momentos**: el motor de puntuación de transcripciones existe como base, pero aún no hay un motor local de voz-a-texto (Whisper u otro) conectado para generar candidatos desde el audio.
- En consecuencia, la exportación por lotes necesita candidatos con tiempos válidos; no inventa momentos destacados.
- El análisis facial actual muestrea fotogramas y no controla todavía el encuadre dinámico durante la exportación.
- No publica directamente en TikTok, YouTube, Facebook o Instagram.
- Este ZIP contiene código fuente, no un APK instalado.

## Abrir el proyecto
1. Extrae el ZIP.
2. Abre la carpeta raíz en Android Studio.
3. Permite que Gradle descargue las dependencias.
4. Compila y prueba en un dispositivo Android físico.

## Estado de validación
No se ha compilado ni probado en un OUKITEL G3 en este entorno. La API de Media3 Transformer y el comportamiento de exportación deben verificarse en Android Studio y en el teléfono antes de considerar la versión lista para uso.

## Siguiente fase sugerida
Integrar transcripción local con marcas de tiempo, generar automáticamente hasta 10 candidatos y conectar esos candidatos al exportador por lotes.
