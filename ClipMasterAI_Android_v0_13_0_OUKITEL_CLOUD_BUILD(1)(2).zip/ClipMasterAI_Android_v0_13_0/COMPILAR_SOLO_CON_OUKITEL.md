# Compilar ClipMaster AI usando solamente el OUKITEL G3

Este proyecto incluye un flujo de compilación en GitHub Actions. La compilación se realiza en los servidores de GitHub; el teléfono solo se usa para subir el proyecto, iniciar el proceso y descargar el APK.

## Requisitos
- Navegador en el OUKITEL G3 y conexión a Internet.
- Cuenta gratuita de GitHub.
- El archivo ZIP de este proyecto.

## Pasos
1. En el navegador, entra en https://github.com y crea una cuenta o inicia sesión.
2. Crea un repositorio nuevo, por ejemplo `ClipMasterAI-Android`. Para mantener el código privado, selecciona **Private**.
3. Descomprime este ZIP con el administrador de archivos del teléfono.
4. Sube el contenido de la carpeta `ClipMasterAI_Android_v0_13_0` al repositorio, conservando también la carpeta oculta `.github/workflows` y el archivo `android-apk.yml`. No subas el ZIP como único archivo: GitHub debe ver `app/`, `build.gradle.kts`, `settings.gradle.kts` y `.github/` en la raíz del repositorio.
5. En GitHub, abre la pestaña **Actions**. Si aparece una solicitud para habilitar Actions, acéptala.
6. Selecciona **Build ClipMaster AI APK** y pulsa **Run workflow**.
7. Espera a que el trabajo termine con una marca verde. Abre la ejecución y baja hasta **Artifacts**.
8. Descarga `ClipMasterAI-debug-APK`, descomprime ese archivo y localiza `app-debug.apk`.
9. Abre `app-debug.apk` en el teléfono. Si Android lo solicita, permite instalar aplicaciones desde el navegador o administrador de archivos que usaste, y vuelve a abrir el APK.

## Importante
- Este flujo intenta compilar la versión de depuración. No es una APK ya compilada ni una garantía de que la primera compilación termine sin errores.
- La compilación descarga dependencias y el código fuente oficial de whisper.cpp desde Internet.
- El procesamiento de video y la transcripción están diseñados para ejecutarse localmente en el teléfono. No subas videos personales al repositorio.
- El modelo de Whisper no está incluido en el APK/proyecto. Para transcribir, después de instalar habrá que colocar un modelo GGML compatible en el almacenamiento local según la pantalla/README de la aplicación.
- Si la ejecución falla, abre el trabajo rojo en Actions y comparte aquí el texto del primer error relevante (sin contraseñas ni tokens). No publiques secretos de GitHub.
