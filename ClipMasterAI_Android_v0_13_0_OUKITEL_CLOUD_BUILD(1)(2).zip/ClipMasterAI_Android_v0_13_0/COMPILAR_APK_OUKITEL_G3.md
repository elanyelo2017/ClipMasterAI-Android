# Compilar e instalar ClipMaster AI v0.13.0 en OUKITEL G3

Esta guía genera un APK de depuración (`debug`) para pruebas en un teléfono Android ARM64. La compilación se realiza en un ordenador Windows con Android Studio; no se puede generar el APK instalando solamente el ZIP en el teléfono.

## 1. Preparar el ordenador

1. Instala **Android Studio** desde https://developer.android.com/studio.
2. Durante la instalación, permite instalar Android SDK y Android SDK Platform-Tools.
3. Abre Android Studio y entra en **Tools > SDK Manager**.
4. En **SDK Platforms**, instala **Android 15 / API 35** (o la plataforma API 35 disponible).
5. En **SDK Tools**, marca e instala:
   - Android SDK Build-Tools.
   - Android SDK Platform-Tools.
   - Android SDK Command-line Tools.
   - **NDK (Side by side)**.
   - **CMake 3.22.1**.
6. Instala **Git for Windows** desde https://git-scm.com/download/win.

## 2. Preparar whisper.cpp

1. Descomprime el ZIP del proyecto en una carpeta sencilla, por ejemplo `C:\ClipMasterAI`.
2. Abre esa carpeta y ejecuta `setup_whisper.bat`.
3. Espera a que termine la descarga del repositorio oficial `ggml-org/whisper.cpp`.
4. Comprueba que existe esta carpeta: `app\src\main\cpp\whisper.cpp`.

Este paso requiere internet en el ordenador. No sube tus videos: descarga el código fuente necesario para compilar el motor local.

## 3. Abrir y compilar

1. Abre Android Studio.
2. Selecciona **Open** y elige la carpeta raíz que contiene `settings.gradle.kts`.
3. Espera a que termine la sincronización de Gradle. Acepta instalar los componentes que Android Studio solicite.
4. Si Android Studio pregunta por el JDK de Gradle, selecciona el **JDK integrado (Embedded JDK)**.
5. Abre **View > Tool Windows > Build** para revisar el resultado.
6. En la terminal integrada de Android Studio, ejecuta:

   ```powershell
   .\gradlew.bat assembleDebug
   ```

   Si esta carpeta de proyecto no contiene `gradlew.bat`, usa Android Studio para crear/añadir el Gradle Wrapper con Gradle 8.9 y vuelve a ejecutar el comando. No sustituyas los archivos `build.gradle.kts` por otros de versiones distintas.

7. Si termina correctamente, el APK estará en:

   `app\build\outputs\apk\debug\app-debug.apk`

## 4. Instalar en el OUKITEL G3

**Por cable USB:**

1. En el teléfono, activa Opciones de desarrollador y Depuración USB.
2. Conecta el teléfono al ordenador y acepta el aviso de autorización.
3. Desde la terminal del proyecto ejecuta:

   ```powershell
   adb install -r app\build\outputs\apk\debug\app-debug.apk
   ```

**Sin cable:** copia `app-debug.apk` al teléfono, ábrelo desde el administrador de archivos y autoriza temporalmente la instalación desde esa fuente si Android lo solicita.

## 5. Primera ejecución

1. Abre ClipMaster AI.
2. Importa un video local de prueba.
3. Importa un modelo Whisper GGML compatible, por ejemplo `ggml-tiny.bin`, desde una fuente oficial y respetando su licencia.
4. Comprueba que la biblioteca nativa ARM64 está disponible y prueba primero con un video corto.
5. Exporta un clip y revisa el MP4 y su archivo SRT lateral.

El modelo Whisper no viene incluido en el ZIP. Una vez instalado el motor y copiado el modelo al almacenamiento privado de la aplicación, la transcripción se procesa localmente. Los archivos SRT son independientes: no están incrustados en la imagen del MP4.

## Importante: estado de esta entrega

- Proyecto fuente: v0.13.0.
- ABI configurada: `arm64-v8a`.
- `minSdk`: 26; `compileSdk` y `targetSdk`: 35.
- Esta carpeta aún no contiene un APK compilado.
- La compilación y la instalación en OUKITEL G3 deben verificarse en un ordenador y en el teléfono reales.
- Si Gradle o CMake muestran un error, conserva el texto completo del error para corregirlo; no se debe asumir que el APK está listo hasta que `assembleDebug` termine correctamente.
