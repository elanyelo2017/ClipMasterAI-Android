package com.clipmasterai

/** Parser local de subtítulos SRT y WebVTT. No requiere Internet ni servicios externos. */
object SubtitleParser {
    private val timePattern = Regex("(?m)((?:\\d{2}:)?\\d{2}:\\d{2}[,.]\\d{3})\\s+-->\\s+((?:\\d{2}:)?\\d{2}:\\d{2}[,.]\\d{3})")

    fun parse(content: String): List<TimedSentence> {
        val normalized = content.removePrefix("\uFEFF").replace("\r\n", "\n").replace('\r', '\n')
        return timePattern.findAll(normalized).mapNotNull { match ->
            val startMs = toMillis(match.groupValues[1])
            val endMs = toMillis(match.groupValues[2])
            val start = (startMs / 1000L).toInt()
            val end = ((endMs + 999L) / 1000L).toInt()
            val after = normalized.substring(match.range.last + 1)
            val text = after.substringBefore("\n\n").lines()
                .filterNot { it.trim().matches(Regex("\\d+")) }
                .joinToString(" ") { it.replace(Regex("<[^>]*>"), "").trim() }
                .replace(Regex("\\s+"), " ").trim()
            if (endMs > startMs && text.isNotBlank()) TimedSentence(start, end, text, startMs, endMs) else null
        }.distinctBy { Triple(it.start, it.end, it.text) }.toList()
    }

    private fun toMillis(value: String): Long {
        val parts = value.replace(',', '.').split(':')
        val clock = if (parts.size == 3) parts else listOf("0", parts[0], parts[1])
        val hours = clock[0].toLong()
        val minutes = clock[1].toLong()
        val secondsParts = clock[2].split('.')
        val seconds = secondsParts[0].toLong()
        val millis = secondsParts.getOrNull(1)?.padEnd(3, '0')?.take(3)?.toLong() ?: 0L
        return ((hours * 3600L + minutes * 60L + seconds) * 1000L) + millis
    }
}
