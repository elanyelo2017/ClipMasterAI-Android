package com.clipmasterai

import java.io.File
import java.util.Locale

/** Escribe subtítulos SRT laterales recortados al tiempo exacto de cada clip. */
object SubtitleExporter {
    fun writeClipSrt(outputVideo: File, clipStartSeconds: Int, clipEndSeconds: Int, cues: List<TimedSentence>): File? {
        val clipStartMs = clipStartSeconds * 1000L
        val clipEndMs = clipEndSeconds * 1000L
        val selected = cues.mapNotNull { cue ->
            val start = maxOf(cue.startMs, clipStartMs)
            val end = minOf(cue.endMs, clipEndMs)
            if (end <= start || cue.text.isBlank()) null
            else Cue((start - clipStartMs).coerceAtLeast(0L), (end - clipStartMs).coerceAtLeast(0L), cue.text.trim())
        }
        if (selected.isEmpty()) return null
        val srt = buildString {
            selected.forEachIndexed { index, cue ->
                append(index + 1).append('\n')
                append(formatTimestamp(cue.startMs)).append(" --> ").append(formatTimestamp(cue.endMs)).append('\n')
                append(cue.text).append("\n\n")
            }
        }
        val file = File(outputVideo.parentFile, outputVideo.nameWithoutExtension + ".srt")
        file.writeText(srt, Charsets.UTF_8)
        return file
    }

    private fun formatTimestamp(ms: Long): String {
        val safe = ms.coerceAtLeast(0L)
        val hours = safe / 3_600_000L
        val minutes = (safe % 3_600_000L) / 60_000L
        val seconds = (safe % 60_000L) / 1_000L
        val millis = safe % 1_000L
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", hours, minutes, seconds, millis)
    }

    private data class Cue(val startMs: Long, val endMs: Long, val text: String)
}
