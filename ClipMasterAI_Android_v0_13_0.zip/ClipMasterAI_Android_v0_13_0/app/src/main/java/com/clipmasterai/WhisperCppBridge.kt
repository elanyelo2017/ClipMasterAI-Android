package com.clipmasterai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** JNI adapter for the official whisper.cpp engine. Requires the native library and a local GGML model. */
class WhisperCppBridge(private val modelFile: File) : LocalTranscriptionEngine {
    companion object {
        private val nativeAvailable: Boolean = try {
            System.loadLibrary("clipmaster_whisper")
            true
        } catch (_: UnsatisfiedLinkError) {
            false
        } catch (_: SecurityException) {
            false
        }
    }
    fun isAvailable(): Boolean = nativeAvailable
    private external fun nativeTranscribe(modelPath: String, wavPath: String): Array<String>

    override suspend fun transcribe(wavFilePath: String): List<TimedSentence> = withContext(Dispatchers.IO) {
        check(nativeAvailable) {
            "No está compilada la biblioteca Whisper para ARM64. Revisa la carpeta app/src/main/cpp/whisper.cpp."
        }
        check(modelFile.isFile && modelFile.length() > 10L * 1024 * 1024) {
            "No se encontró un modelo Whisper válido. Importa ggml-tiny.bin primero."
        }
        val wav = File(wavFilePath)
        check(wav.isFile && wav.length() > 44) { "El WAV de entrada no existe o está vacío." }
        nativeTranscribe(modelFile.absolutePath, wav.absolutePath).mapNotNull { row ->
            val parts = row.split('|', limit = 3)
            if (parts.size != 3) return@mapNotNull null
            val startMs = parts[0].toLongOrNull() ?: return@mapNotNull null
            val endMs = parts[1].toLongOrNull() ?: return@mapNotNull null
            val text = parts[2].trim()
            if (endMs <= startMs || text.isBlank()) null
            else TimedSentence(
                start = (startMs / 1000L).toInt(),
                end = ((endMs + 999L) / 1000L).toInt().coerceAtLeast((startMs / 1000L).toInt() + 1),
                text = text,
                startMs = startMs,
                endMs = endMs
            )
        }
    }
}
