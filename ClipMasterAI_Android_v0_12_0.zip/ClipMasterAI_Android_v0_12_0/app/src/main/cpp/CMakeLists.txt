cmake_minimum_required(VERSION 3.22.1)
project(clipmaster_whisper LANGUAGES C CXX)

# Place the official whisper.cpp repository at app/src/main/cpp/whisper.cpp.
# It is intentionally not copied into this ZIP; see README for the reproducible setup.
set(WHISPER_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_SERVER OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_BENCHMARKS OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE OFF CACHE BOOL "" FORCE)
add_subdirectory(whisper.cpp)

add_library(clipmaster_whisper SHARED whisper_jni.cpp)
target_compile_features(clipmaster_whisper PRIVATE cxx_std_17)
target_include_directories(clipmaster_whisper PRIVATE whisper.cpp/include)
find_library(log-lib log)
target_link_libraries(clipmaster_whisper PRIVATE whisper ${log-lib})
