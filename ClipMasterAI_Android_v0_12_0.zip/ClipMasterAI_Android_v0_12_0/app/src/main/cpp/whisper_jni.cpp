#include <jni.h>
#include <android/log.h>
#include <whisper.h>
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <string>
#include <vector>

#define LOG_TAG "ClipMasterWhisper"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static void throwIllegalState(JNIEnv* env, const std::string& message) {
    jclass cls = env->FindClass("java/lang/IllegalStateException");
    if (cls) env->ThrowNew(cls, message.c_str());
}
static uint16_t u16(const unsigned char* p) { return uint16_t(p[0]) | (uint16_t(p[1]) << 8); }
static uint32_t u32(const unsigned char* p) {
    return uint32_t(p[0]) | (uint32_t(p[1]) << 8) |
           (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 24);
}

struct WavInfo {
    std::streamoff dataOffset = 0;
    uint32_t dataBytes = 0;
    uint32_t sampleRate = 0;
    uint16_t channels = 0;
    uint16_t bits = 0;
    uint16_t format = 0;
};

// Parse the RIFF header without loading the full recording into memory.
static bool inspectWav(const std::string& path, WavInfo& info, std::string& error) {
    std::ifstream in(path, std::ios::binary);
    unsigned char header[12];
    if (!in.read(reinterpret_cast<char*>(header), sizeof(header)) ||
        std::string(reinterpret_cast<char*>(header), 4) != "RIFF" ||
        std::string(reinterpret_cast<char*>(header + 8), 4) != "WAVE") {
        error = "El archivo no es WAV/RIFF válido.";
        return false;
    }
    bool fmtFound = false, dataFound = false;
    while (in && !(fmtFound && dataFound)) {
        unsigned char chunk[8];
        if (!in.read(reinterpret_cast<char*>(chunk), sizeof(chunk))) break;
        const uint32_t size = u32(chunk + 4);
        const std::string id(reinterpret_cast<char*>(chunk), 4);
        const std::streamoff bodyOffset = in.tellg();
        if (id == "fmt ") {
            if (size < 16 || size > 4096) { error = "Chunk WAV fmt inválido."; return false; }
            std::vector<unsigned char> body(size);
            if (!in.read(reinterpret_cast<char*>(body.data()), size)) { error = "No se pudo leer el formato WAV."; return false; }
            info.format = u16(body.data());
            info.channels = u16(body.data() + 2);
            info.sampleRate = u32(body.data() + 4);
            info.bits = u16(body.data() + 14);
            fmtFound = true;
        } else if (id == "data") {
            info.dataOffset = bodyOffset;
            info.dataBytes = size;
            dataFound = true;
        }
        in.clear();
        in.seekg(bodyOffset + static_cast<std::streamoff>(size + (size & 1)));
    }
    if (!fmtFound || !dataFound || info.format != 1 || info.channels != 1 ||
        info.sampleRate != 16000 || info.bits != 16 || info.dataBytes < 2) {
        error = "Whisper requiere WAV PCM mono, 16 kHz y 16 bits.";
        return false;
    }
    return true;
}

extern "C" JNIEXPORT jobjectArray JNICALL
Java_com_clipmasterai_WhisperCppBridge_nativeTranscribe(
        JNIEnv* env, jobject /* thiz */, jstring modelPath, jstring wavPath) {
    const char* modelChars = env->GetStringUTFChars(modelPath, nullptr);
    const char* wavChars = env->GetStringUTFChars(wavPath, nullptr);
    if (!modelChars || !wavChars) {
        if (modelChars) env->ReleaseStringUTFChars(modelPath, modelChars);
        if (wavChars) env->ReleaseStringUTFChars(wavPath, wavChars);
        throwIllegalState(env, "No se pudieron leer las rutas de modelo/audio.");
        return nullptr;
    }
    const std::string model(modelChars), wav(wavChars);
    env->ReleaseStringUTFChars(modelPath, modelChars);
    env->ReleaseStringUTFChars(wavPath, wavChars);

    WavInfo info;
    std::string error;
    if (!inspectWav(wav, info, error)) { throwIllegalState(env, error); return nullptr; }

    whisper_context_params cparams = whisper_context_default_params();
    cparams.use_gpu = false;
    whisper_context* ctx = whisper_init_from_file_with_params(model.c_str(), cparams);
    if (!ctx) { throwIllegalState(env, "Whisper no pudo cargar el modelo GGML. Comprueba el archivo importado."); return nullptr; }

    whisper_full_params params = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    params.n_threads = 2;
    params.translate = false;
    params.no_context = true;
    params.single_segment = false;
    params.print_realtime = false;
    params.print_progress = false;
    params.print_timestamps = false;
    params.print_special = false;
    params.language = "es";
    params.max_len = 0;
    params.token_timestamps = false;

    // Process long WAV files in 30-second windows to limit memory use on the phone.
    constexpr uint64_t kSamplesPerChunk = 30ULL * 16000ULL;
    const uint64_t totalSamples = info.dataBytes / 2ULL;
    std::ifstream audio(wav, std::ios::binary);
    std::vector<std::string> rows;
    std::vector<unsigned char> pcm(kSamplesPerChunk * 2ULL);
    std::vector<float> samples;
    samples.reserve(kSamplesPerChunk);

    for (uint64_t offset = 0; offset < totalSamples; offset += kSamplesPerChunk) {
        const uint64_t count = std::min(kSamplesPerChunk, totalSamples - offset);
        audio.clear();
        audio.seekg(info.dataOffset + static_cast<std::streamoff>(offset * 2ULL));
        const size_t bytes = static_cast<size_t>(count * 2ULL);
        if (!audio.read(reinterpret_cast<char*>(pcm.data()), static_cast<std::streamsize>(bytes))) {
            whisper_free(ctx);
            throwIllegalState(env, "No se pudo leer un fragmento del audio WAV.");
            return nullptr;
        }
        samples.resize(static_cast<size_t>(count));
        for (size_t i = 0; i < samples.size(); ++i) {
            const int16_t value = static_cast<int16_t>(u16(pcm.data() + i * 2));
            samples[i] = static_cast<float>(value) / 32768.0f;
        }
        if (samples.size() < 8000) break;
        if (whisper_full(ctx, params, samples.data(), static_cast<int>(samples.size())) != 0) {
            whisper_free(ctx);
            throwIllegalState(env, "Falló Whisper al procesar un fragmento. Prueba con el modelo tiny o un video más corto.");
            return nullptr;
        }
        const int segmentCount = whisper_full_n_segments(ctx);
        const int64_t chunkOffsetMs = static_cast<int64_t>(offset * 1000ULL / 16000ULL);
        for (int i = 0; i < segmentCount; ++i) {
            const int64_t startMs = chunkOffsetMs + whisper_full_get_segment_t0(ctx, i) * 10;
            const int64_t endMs = chunkOffsetMs + whisper_full_get_segment_t1(ctx, i) * 10;
            const char* segmentText = whisper_full_get_segment_text(ctx, i);
            if (endMs > startMs && segmentText && *segmentText) {
                rows.push_back(std::to_string(startMs) + "|" + std::to_string(endMs) + "|" + segmentText);
            }
        }
    }
    whisper_free(ctx);
    jclass stringClass = env->FindClass("java/lang/String");
    jobjectArray output = env->NewObjectArray(static_cast<jsize>(rows.size()), stringClass, nullptr);
    for (jsize i = 0; i < static_cast<jsize>(rows.size()); ++i) {
        jstring value = env->NewStringUTF(rows[static_cast<size_t>(i)].c_str());
        env->SetObjectArrayElement(output, i, value);
        env->DeleteLocalRef(value);
    }
    return output;
}
