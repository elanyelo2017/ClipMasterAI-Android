package com.clipmasterai

/**
 * Contrato de reconocimiento de voz local. Whisper.cpp procesa WAV mono PCM16 a 16 kHz
 * y devuelve segmentos con marcas de tiempo.
 */
interface LocalTranscriptionEngine {
    suspend fun transcribe(wavFilePath: String): List<TimedSentence>
}

/** Especificación de audio de entrada para el motor Whisper local. */
data class AudioInputSpec(
    val sampleRateHz: Int = 16_000,
    val channels: Int = 1,
    val encoding: String = "PCM_16BIT"
)
