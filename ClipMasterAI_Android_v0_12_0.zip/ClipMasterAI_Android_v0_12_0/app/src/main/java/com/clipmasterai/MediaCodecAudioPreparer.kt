package com.clipmasterai

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.roundToInt

/**
 * Extracts the first audio track and decodes it locally to WAV mono PCM16/16 kHz.
 * No network access is used. Supports decoder output in PCM16 mono or stereo.
 */
class MediaCodecAudioPreparer(
    private val cacheDir: File
) : VideoAudioPreparer {

    override suspend fun extractMono16KhzWav(videoPath: String): PreparedAudio =
        withContext(Dispatchers.IO) {
            val input = File(videoPath)
            require(input.isFile) { "No se encontró el video de entrada" }
            if (!cacheDir.exists() && !cacheDir.mkdirs()) {
                error("No se pudo crear la carpeta temporal")
            }
            val wav = File(cacheDir, "clipmaster_audio_${System.nanoTime()}.wav")
            val extractor = MediaExtractor()
            var decoder: MediaCodec? = null
            var completed = false
            try {
                extractor.setDataSource(input.absolutePath)
                val track = (0 until extractor.trackCount).firstOrNull { index ->
                    extractor.getTrackFormat(index).getString(MediaFormat.KEY_MIME)
                        ?.startsWith("audio/") == true
                } ?: error("El video no contiene una pista de audio")
                val inputFormat = extractor.getTrackFormat(track)
                val mime = inputFormat.getString(MediaFormat.KEY_MIME)
                    ?: error("Formato de audio desconocido")
                extractor.selectTrack(track)
                decoder = MediaCodec.createDecoderByType(mime)
                decoder.configure(inputFormat, null, null, 0)
                decoder.start()

                RandomAccessFile(wav, "rw").use { out ->
                    out.setLength(0)
                    out.write(ByteArray(44)) // WAV header is finalized after decoding.
                    val info = MediaCodec.BufferInfo()
                    var inputEnded = false
                    var outputEnded = false
                    var sampleRate = inputFormat.getIntegerOrDefault(MediaFormat.KEY_SAMPLE_RATE, 48_000)
                    var channels = inputFormat.getIntegerOrDefault(MediaFormat.KEY_CHANNEL_COUNT, 2)
                    var pcmEncoding = 2 // AudioFormat.ENCODING_PCM_16BIT
                    var resampler = Mono16kResampler(sampleRate, out)

                    while (!outputEnded) {
                        currentCoroutineContext().ensureActive()
                        if (!inputEnded) {
                            val inputIndex = decoder.dequeueInputBuffer(TIMEOUT_US)
                            if (inputIndex >= 0) {
                                val buffer = decoder.getInputBuffer(inputIndex)
                                    ?: error("No se pudo obtener el buffer de entrada")
                                val size = extractor.readSampleData(buffer, 0)
                                if (size < 0) {
                                    decoder.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                    inputEnded = true
                                } else {
                                    decoder.queueInputBuffer(
                                        inputIndex, 0, size, extractor.sampleTime,
                                        0
                                    )
                                    extractor.advance()
                                }
                            }
                        }

                        when (val outputIndex = decoder.dequeueOutputBuffer(info, TIMEOUT_US)) {
                            MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                                val format = decoder.outputFormat
                                sampleRate = format.getIntegerOrDefault(MediaFormat.KEY_SAMPLE_RATE, sampleRate)
                                channels = format.getIntegerOrDefault(MediaFormat.KEY_CHANNEL_COUNT, channels)
                                pcmEncoding = format.getIntegerOrDefault(MediaFormat.KEY_PCM_ENCODING, 2)
                                check(pcmEncoding == 2) {
                                    "El decodificador entregó PCM no compatible; se requiere PCM de 16 bits"
                                }
                                resampler = Mono16kResampler(sampleRate, out)
                            }
                            MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                            else -> if (outputIndex >= 0) {
                                val buffer = decoder.getOutputBuffer(outputIndex)
                                if (buffer != null && info.size > 0) {
                                    check(channels == 1 || channels == 2) {
                                        "Solo se admite audio mono o estéreo"
                                    }
                                    val pcm = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
                                    pcm.position(info.offset)
                                    pcm.limit(info.offset + info.size)
                                    resampler.consume(pcm.slice().order(ByteOrder.LITTLE_ENDIAN), channels)
                                }
                                outputEnded = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                                decoder.releaseOutputBuffer(outputIndex, false)
                            }
                        }
                    }
                    resampler.finish()
                    val dataSize = out.length() - 44L
                    require(dataSize > 0L) { "No se pudo extraer audio del video" }
                    require(dataSize <= 0xFFFF_FFFFL - 36L) { "El audio extraído supera el límite WAV de 4 GB" }
                    writeWavHeader(out, dataSize)
                }
                completed = true
                PreparedAudio(wavFile = wav)
            } finally {
                try { decoder?.stop() } catch (_: Exception) { }
                try { decoder?.release() } catch (_: Exception) { }
                extractor.release()
                if (!completed) wav.delete()
            }
        }

    private class Mono16kResampler(inputRate: Int, private val out: RandomAccessFile) {
        private val step = inputRate.toDouble() / OUTPUT_RATE
        private var sourceIndex = -1L
        private var nextOutputPosition = 0.0
        private var previous = 0.0
        private val writeBuffer = ByteArray(8192)
        private var writeCount = 0

        fun consume(buffer: ByteBuffer, channels: Int) {
            val frameBytes = channels * 2
            while (buffer.remaining() >= frameBytes) {
                var mono = 0.0
                repeat(channels) { mono += buffer.short.toDouble() / channels }
                sourceIndex++
                if (sourceIndex == 0L) {
                    emit(mono)
                } else {
                    while (nextOutputPosition <= sourceIndex.toDouble()) {
                        val fraction = (nextOutputPosition - (sourceIndex - 1)).coerceIn(0.0, 1.0)
                        emit(previous + (mono - previous) * fraction)
                    }
                }
                previous = mono
            }
        }

        fun finish() = flush()

        private fun emit(value: Double) {
            val sample = value.roundToInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            writeBuffer[writeCount++] = (sample.toInt() and 0xff).toByte()
            writeBuffer[writeCount++] = ((sample.toInt() shr 8) and 0xff).toByte()
            nextOutputPosition += step
            if (writeCount >= writeBuffer.size - 1) flush()
        }

        private fun flush() {
            if (writeCount > 0) {
                out.write(writeBuffer, 0, writeCount)
                writeCount = 0
            }
        }
    }

    private fun writeWavHeader(file: RandomAccessFile, dataSize: Long) {
        val byteRate = OUTPUT_RATE * 2
        file.seek(0)
        file.writeBytes("RIFF")
        file.writeIntLE((36L + dataSize).toInt())
        file.writeBytes("WAVE")
        file.writeBytes("fmt ")
        file.writeIntLE(16)
        file.writeShortLE(1)
        file.writeShortLE(1)
        file.writeIntLE(OUTPUT_RATE)
        file.writeIntLE(byteRate)
        file.writeShortLE(2)
        file.writeShortLE(16)
        file.writeBytes("data")
        file.writeIntLE(dataSize.toInt())
    }

    private fun RandomAccessFile.writeIntLE(value: Int) {
        write(value and 0xff); write((value ushr 8) and 0xff)
        write((value ushr 16) and 0xff); write((value ushr 24) and 0xff)
    }

    private fun RandomAccessFile.writeShortLE(value: Int) {
        write(value and 0xff); write((value ushr 8) and 0xff)
    }

    private fun MediaFormat.getIntegerOrDefault(key: String, fallback: Int): Int =
        if (containsKey(key)) getInteger(key) else fallback

    companion object {
        private const val OUTPUT_RATE = 16_000
        private const val TIMEOUT_US = 10_000L
    }
}
