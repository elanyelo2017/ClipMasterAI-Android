package com.clipmasterai

import java.io.File

/** Output contract for the upcoming MediaExtractor/MediaCodec audio decoder. */
data class PreparedAudio(
    val wavFile: File,
    val sampleRateHz: Int = 16_000,
    val channels: Int = 1,
    val bitsPerSample: Int = 16
) {
    init {
        require(sampleRateHz == 16_000 && channels == 1 && bitsPerSample == 16) {
            "Whisper requiere audio mono PCM de 16 kHz y 16 bits en esta integración"
        }
    }
}

interface VideoAudioPreparer {
    suspend fun extractMono16KhzWav(videoPath: String): PreparedAudio
}
