package com.clipmasterai

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/** Keeps a user-supplied GGML Whisper model in app-private storage for repeat offline use. */
class LocalModelStore(context: Context) {
    private val modelDir = File(context.filesDir, "asr-models").apply { mkdirs() }
    val defaultModel: File get() = File(modelDir, "ggml-tiny.bin")

    suspend fun installFromUri(context: Context, uri: Uri, fileName: String = "ggml-tiny.bin"): File =
        withContext(Dispatchers.IO) {
            require(fileName.matches(Regex("[A-Za-z0-9._-]{1,80}"))) { "Nombre de modelo no válido" }
            val target = File(modelDir, fileName)
            val temp = File(modelDir, "$fileName.part")
            try {
                val input = requireNotNull(context.contentResolver.openInputStream(uri)) {
                    "No se pudo abrir el archivo seleccionado"
                }
                input.use { source -> FileOutputStream(temp).use { out -> source.copyTo(out) } }
                require(temp.length() >= 10L * 1024 * 1024) {
                    "El archivo parece demasiado pequeño para ser un modelo Whisper válido"
                }
                if (target.exists()) target.delete()
                check(temp.renameTo(target)) { "No se pudo guardar el modelo" }
                target
            } finally {
                if (temp.exists()) temp.delete()
            }
        }

    fun installedModels(): List<File> = modelDir.listFiles()
        ?.filter { it.isFile && it.extension.equals("bin", true) }
        ?.sortedBy { it.name } ?: emptyList()
}
