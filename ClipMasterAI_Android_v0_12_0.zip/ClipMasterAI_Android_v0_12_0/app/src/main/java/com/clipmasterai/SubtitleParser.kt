package com.clipmasterai

/** Parser local de subtítulos SRT y WebVTT. No requiere Internet ni servicios externos. */
object SubtitleParser {
    private val timePattern = Regex("(?m)((?:\\d{2}:)?\\d{2}:\\d{2}[,.]\\d{3})\\s+-->\\s+((?:\\d{2}:)?\\d{2}:\\d{2}[,.]\\d{3})")

    fun parse(content: String): List<TimedSentence> {
        val normalized = content.removePrefix("\uFEFF").replace("\r\n", "\n").replace('\r', '\n')
        return timePattern.findAll(normalized).mapNotNull { match ->
            val start = toSeconds(match.groupValues[1])
            val end = toSeconds(match.groupValues[2])
            val after = normalized.substring(match.range.last + 1)
            val text = after.substringBefore("\n\n").lines()
                .filterNot { it.trim().matches(Regex("\\d+")) }
                .joinToString(" ") { it.replace(Regex("<[^>]*>"), "").trim() }
                .replace(Regex("\\s+"), " ").trim()
            if (end > start && text.isNotBlank()) TimedSentence(start, end, text) else null
        }.distinctBy { Triple(it.start, it.end, it.text) }.toList()
    }

    private fun toSeconds(value: String): Int {
        val parts = value.replace(',', '.').split(':')
        val offset = if (parts.size == 3) 1 else 0
        val hours = if (offset == 1) parts[0].toInt() else 0
        val minutes = parts[offset].toInt()
        val seconds = parts[offset + 1].substringBefore('.').toInt()
        return hours * 3600 + minutes * 60 + seconds
    }
}
