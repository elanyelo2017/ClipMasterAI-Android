package com.clipmasterai

/**
 * Local, deterministic first-pass planner. It ranks transcript windows; it does not
 * claim to predict virality or replace a trained on-device model.
 */
object ViralClipPlanner {
    private const val TARGET_SECONDS = 45
    private const val MIN_SECONDS = 30
    private const val MAX_SECONDS = 60

    private val hooks = listOf(
        "no vas a creer", "increíble", "secreto", "error", "nunca", "siempre",
        "por qué", "cómo", "la verdad", "importante", "sorpresa", "mejor",
        "peor", "atención", "resultado", "finalmente", "imagina", "aprendí",
        "consejo", "problema", "solución", "dinero", "gratis", " cuidado"
    )

    fun plan(lines: List<TimedSentence>): List<ClipCandidate> {
        val valid = lines.filter { it.start >= 0 && it.end > it.start && it.text.isNotBlank() }
            .sortedBy { it.start }
        if (valid.isEmpty()) return emptyList()

        val seeds = valid.mapNotNull { line ->
            val score = scoreLine(line.text)
            if (score <= 0) null else line to score
        }.sortedByDescending { it.second }

        val selected = mutableListOf<ClipCandidate>()
        for ((seed, seedScore) in seeds) {
            if (selected.size >= 10) break
            val desiredStart = (seed.start - (TARGET_SECONDS / 2)).coerceAtLeast(0)
            val desiredEnd = desiredStart + TARGET_SECONDS
            val windowLines = valid.filter { it.end > desiredStart && it.start < desiredEnd }
            if (windowLines.isEmpty()) continue

            var start = windowLines.first().start
            var end = windowLines.last().end
            if (end - start < MIN_SECONDS) {
                val extra = MIN_SECONDS - (end - start)
                start = (start - extra / 2).coerceAtLeast(0)
                end = start + MIN_SECONDS
            }
            if (end - start > MAX_SECONDS) end = start + MAX_SECONDS
            if (end <= start) continue

            // Avoid near-duplicate moments and heavily overlapping exports.
            if (selected.any { existing ->
                    kotlin.math.abs(existing.startSeconds - start) < 20 ||
                        (start < existing.endSeconds && end > existing.startSeconds)
                }) continue

            val text = windowLines.joinToString(" ") { it.text }.take(500)
            val title = makeTitle(seed.text)
            selected += ClipCandidate(
                startSeconds = start,
                endSeconds = end,
                score = seedScore.coerceAtMost(10),
                reason = "Gancho detectado en la transcripción",
                title = title,
                description = "$title. Un fragmento seleccionado automáticamente de tu video.",
                hashtags = makeHashtags(text)
            )
        }
        return selected.sortedByDescending { it.score }
    }

    private fun scoreLine(text: String): Int {
        val normalized = text.lowercase()
        val hookCount = hooks.count { normalized.contains(it) }
        val question = if ('?' in text || '¿' in text) 2 else 0
        val emphasis = if ('!' in text || '¡' in text) 1 else 0
        val lengthBonus = if (text.trim().split(Regex("\\s+")).size in 5..25) 1 else 0
        return hookCount * 3 + question + emphasis + lengthBonus
    }

    private fun makeTitle(seed: String): String {
        val clean = seed.replace(Regex("\\s+"), " ").trim().trim('.', '!', '?', '¿', '¡')
        return when {
            clean.isBlank() -> "No te pierdas este momento"
            clean.length <= 68 -> clean.replaceFirstChar { it.uppercase() }
            else -> clean.take(65).substringBeforeLast(' ', clean.take(65)) + "…"
        }
    }

    private fun makeHashtags(text: String): List<String> {
        val tags = linkedSetOf("#Shorts", "#Reels", "#ClipMasterAI")
        val lower = text.lowercase()
        val topics = listOf(
            "dinero" to "#Finanzas", "amor" to "#Amor", "trabajo" to "#Trabajo",
            "éxito" to "#Exito", "motivación" to "#Motivacion", "consejo" to "#Consejos",
            "aprend" to "#Aprendizaje", "secreto" to "#Secretos", "humor" to "#Humor",
            "problema" to "#Soluciones", "youtube" to "#YouTube"
        )
        topics.filter { lower.contains(it.first) }.forEach { tags += it.second }
        return tags.take(8)
    }
}
