package com.clipmasterai

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.media3.common.util.UnstableApi
import java.io.File
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ClipCandidate(
    val startSeconds: Int,
    val endSeconds: Int,
    val score: Int,
    val reason: String,
    val title: String = "Momento destacado",
    val description: String = "Mira este momento del video.",
    val hashtags: List<String> = listOf("#Shorts", "#Reels", "#ClipMasterAI")
)

class ClipViewModel : ViewModel() {
    var selectedVideo by mutableStateOf<Uri?>(null)
        private set
    var candidates by mutableStateOf<List<ClipCandidate>>(emptyList())
        private set
    var status by mutableStateOf("Selecciona un video para comenzar.")
        private set

    fun setVideo(uri: Uri) {
        selectedVideo = uri
        candidates = emptyList()
        status = "Video seleccionado. El análisis de IA se integrará en el siguiente módulo."
    }

    // Recibe segmentos temporizados desde Whisper.cpp o desde un archivo SRT/VTT.
    fun analyzeTranscript(lines: List<TimedSentence>) {
        candidates = HighlightScorer.rank(lines).take(10)
        status = if (candidates.isEmpty()) "No se encontraron momentos; prueba con otra transcripción."
                 else "Se encontraron ${candidates.size} momentos candidatos."
    }
}

data class TimedSentence(val start: Int, val end: Int, val text: String)

object HighlightScorer {
    fun rank(lines: List<TimedSentence>): List<ClipCandidate> =
        ViralClipPlanner.plan(lines).take(10)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ClipMasterScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
@OptIn(UnstableApi::class)
fun ClipMasterScreen(vm: ClipViewModel = viewModel()) {
    val context = LocalContext.current
    var exporting by remember { mutableStateOf(false) }
    var exportMessage by remember { mutableStateOf("") }
    var exportedFile by remember { mutableStateOf<File?>(null) }
    var exporter by remember { mutableStateOf<VerticalVideoExporter?>(null) }
    var batchExporter by remember { mutableStateOf<ClipBatchExporter?>(null) }
    var batchExporting by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var scanningFaces by remember { mutableStateOf(false) }
    var subtitleStatus by remember { mutableStateOf("Importa un archivo .srt o .vtt para analizar sus frases localmente.") }
    var faceScanMessage by remember { mutableStateOf("") }
    var preparingAudio by remember { mutableStateOf(false) }
    var audioPreparationMessage by remember { mutableStateOf("") }
    var transcribing by remember { mutableStateOf(false) }
    var transcriptionMessage by remember { mutableStateOf("Importa un modelo Whisper tiny para activar la transcripción local.") }
    val modelStore = remember { LocalModelStore(context) }
    var modelReady by remember { mutableStateOf(modelStore.defaultModel.isFile) }
    // Detect the JNI library independently: importing a model alone does not install whisper.cpp.
    val whisperEngineReady = remember { WhisperCppBridge(modelStore.defaultModel).isAvailable() }
    val modelPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { modelUri ->
        modelUri?.let { uri ->
            scope.launch {
                transcriptionMessage = "Instalando modelo en el almacenamiento privado..."
                try {
                    val installed = modelStore.installFromUri(context, uri)
                    modelReady = installed.isFile
                    transcriptionMessage = "Modelo instalado: ${installed.name}. Se conservará para uso sin conexión."
                } catch (error: Exception) {
                    transcriptionMessage = "No se pudo instalar el modelo: ${error.message ?: "error desconocido"}"
                }
            }
        }
    }
    val subtitlePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { subtitleUri ->
        subtitleUri?.let { uri ->
            try {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: throw IllegalStateException("No se pudo leer el archivo de subtítulos.")
                val sentences = SubtitleParser.parse(text)
                vm.analyzeTranscript(sentences)
                subtitleStatus = if (sentences.isEmpty()) "No se encontraron subtítulos válidos con marcas de tiempo." else "Leídas ${sentences.size} frases. ${vm.candidates.size} momentos candidatos." 
            } catch (e: Exception) {
                subtitleStatus = "Error al leer subtítulos: ${e.message ?: "archivo no válido"}"
            }
        }
    }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            // Conserva permiso de lectura para acceder al video después.
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                        it, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
            }
            vm.setVideo(it)
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("ClipMaster AI") }) }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Detector inteligente de momentos", style = MaterialTheme.typography.titleLarge)
                Text("Procesamiento local · Sin suscripción · Hasta 10 clips")
                OutlinedButton(onClick = { modelPicker.launch(arrayOf("application/octet-stream", "application/x-binary", "*/*")) }) {
                    Text(if (modelReady) "Cambiar modelo Whisper tiny" else "Importar modelo Whisper tiny.bin")
                }
                Text(if (modelReady) "Modelo local detectado." else "Modelo no instalado. Selecciona un archivo GGML tiny.bin compatible.", style = MaterialTheme.typography.bodySmall)
                Text(
                    if (whisperEngineReady) "Motor Whisper ARM64 cargado. La transcripción se ejecuta en el teléfono."
                    else "Motor Whisper ARM64 no disponible. Hay que preparar whisper.cpp y compilar la app con NDK/CMake.",
                    style = MaterialTheme.typography.bodySmall
                )
                Button(onClick = { picker.launch(arrayOf("video/*")) }) {
                    Text("Seleccionar video")
                }
                OutlinedButton(onClick = { subtitlePicker.launch(arrayOf("text/*", "application/x-subrip", "application/octet-stream")) }) {
                    Text("Importar subtítulos SRT/VTT")
                }
                Text(subtitleStatus, style = MaterialTheme.typography.bodySmall)
                vm.selectedVideo?.let { uri ->
                    Text("Video: ${uri.lastPathSegment ?: uri}")
                    Button(
                        enabled = !scanningFaces,
                        onClick = {
                            scanningFaces = true
                            faceScanMessage = "Preparando análisis local..."
                            scope.launch {
                                try {
                                    val result = VideoFaceScanRepository().scan(
                                        context = context,
                                        uri = uri,
                                        intervalMs = 1_000L,
                                        maxFrames = 120
                                    )
                                    faceScanMessage =
                                        "Análisis terminado: ${result.sampledFrames} fotogramas; " +
                                        "${result.framesWithFaces} con rostros. " +
                                        "Duración: ${formatTime((result.durationMs / 1000).toInt())}."
                                } catch (error: Exception) {
                                    faceScanMessage = "No se pudo analizar el video: ${error.message ?: "error desconocido"}"
                                } finally {
                                    scanningFaces = false
                                }
                            }
                        }
                    ) {
                        Text(if (scanningFaces) "Analizando rostros..." else "Analizar rostros y encuadre")
                    }
                    if (faceScanMessage.isNotBlank()) Text(faceScanMessage)
                    Button(
                        enabled = !preparingAudio,
                        onClick = {
                            preparingAudio = true
                            audioPreparationMessage = "Extrayendo audio localmente a WAV mono 16 kHz..."
                            scope.launch {
                                var copiedVideo: File? = null
                                try {
                                    copiedVideo = withContext(Dispatchers.IO) {
                                        val temp = File(context.cacheDir, "clipmaster_input_${System.nanoTime()}.mp4")
                                        context.contentResolver.openInputStream(uri)?.use { input ->
                                            temp.outputStream().use { output -> input.copyTo(output) }
                                        } ?: error("No se pudo abrir el video seleccionado")
                                        temp
                                    }
                                    val prepared = MediaCodecAudioPreparer(context.cacheDir)
                                        .extractMono16KhzWav(copiedVideo.absolutePath)
                                    audioPreparationMessage = "Audio preparado correctamente: ${prepared.wavFile.name} (mono, 16 kHz, PCM 16 bits)."
                                } catch (error: Exception) {
                                    audioPreparationMessage = "No se pudo preparar el audio: ${error.message ?: "error desconocido"}"
                                } finally {
                                    copiedVideo?.delete()
                                    preparingAudio = false
                                }
                            }
                        }
                    ) {
                        Text(if (preparingAudio) "Preparando audio..." else "Preparar audio para transcripción IA")
                    }
                    if (audioPreparationMessage.isNotBlank()) {
                        Text(audioPreparationMessage, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    }
                    Button(
                        enabled = !transcribing && modelReady && whisperEngineReady,
                        onClick = {
                            transcribing = true
                            transcriptionMessage = "Extrayendo audio y ejecutando Whisper en el teléfono..."
                            scope.launch {
                                var copiedVideo: File? = null
                                var wavFile: File? = null
                                try {
                                    copiedVideo = withContext(Dispatchers.IO) {
                                        val temp = File(context.cacheDir, "clipmaster_asr_${System.nanoTime()}.mp4")
                                        context.contentResolver.openInputStream(uri)?.use { input ->
                                            temp.outputStream().use { output -> input.copyTo(output) }
                                        } ?: error("No se pudo abrir el video seleccionado")
                                        temp
                                    }
                                    val prepared = MediaCodecAudioPreparer(context.cacheDir)
                                        .extractMono16KhzWav(copiedVideo.absolutePath)
                                    wavFile = prepared.wavFile
                                    val lines = WhisperCppBridge(modelStore.defaultModel).transcribe(prepared.wavFile.absolutePath)
                                    vm.analyzeTranscript(lines)
                                    transcriptionMessage = "Transcripción completada: ${lines.size} segmentos. ${vm.candidates.size} clips candidatos detectados."
                                } catch (error: Exception) {
                                    transcriptionMessage = "No se pudo transcribir: ${error.message ?: "error desconocido"}"
                                } finally {
                                    copiedVideo?.delete()
                                    wavFile?.delete()
                                    transcribing = false
                                }
                            }
                        }
                    ) {
                        Text(if (transcribing) "Transcribiendo localmente..." else if (!whisperEngineReady) "Whisper no está compilado" else if (!modelReady) "Importa el modelo Whisper" else "Transcribir y detectar 10 clips")
                    }
                    if (transcriptionMessage.isNotBlank()) {
                        Text(transcriptionMessage, maxLines = 4, overflow = TextOverflow.Ellipsis)
                    }
                    Button(
                        enabled = !exporting,
                        onClick = {
                            exporting = true
                            exportMessage = "Preparando exportación MP4 vertical..."
                            val currentExporter = VerticalVideoExporter(
                                context = context,
                                completionCallback = { file ->
                                    exporting = false
                                    exportedFile = file
                                    exportMessage = "Video exportado correctamente: ${file.name}"
                                },
                                errorCallback = { message ->
                                    exporting = false
                                    exportMessage = "No se pudo exportar: $message"
                                },
                                onProgress = { }
                            )
                            exporter = currentExporter
                            currentExporter.export(uri)
                        }
                    ) {
                        Text(if (exporting) "Exportando MP4..." else "Exportar MP4 vertical 9:16")
                    }
                    if (exportMessage.isNotBlank()) {
                        Text(exportMessage, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    }
                    exportedFile?.let { file ->
                        Text("Guardado en: ${file.parent}")
                    }
                }
                if (vm.candidates.isNotEmpty()) {
                    Button(
                        enabled = !batchExporting && !exporting,
                        onClick = {
                            val selected = vm.selectedVideo ?: return@Button
                            batchExporting = true
                            exportMessage = "Preparando exportación de clips…"
                            val batch = ClipBatchExporter(
                                context = context,
                                onProgress = { current, total, message -> exportMessage = "$message ($current/$total)" },
                                onCompleted = { files ->
                                    batchExporting = false
                                    exportMessage = "Lote terminado: ${files.size} clips guardados en Movies de ClipMaster AI."
                                },
                                onError = { message, files ->
                                    batchExporting = false
                                    exportMessage = "$message Clips completados: ${files.size}."
                                }
                            )
                            batchExporter = batch
                            batch.export(selected, vm.candidates)
                        }
                    ) {
                        Text(if (batchExporting) "Exportando clips…" else "Exportar hasta 10 clips MP4")
                    }
                }
                Text(vm.status)
                HorizontalDivider()
                Text("Momentos candidatos", style = MaterialTheme.typography.titleMedium)
                if (vm.candidates.isEmpty()) {
                    Text("Todavía no hay resultados. Selecciona un video, importa el modelo Whisper tiny y pulsa Transcribir y detectar 10 clips. También puedes importar subtítulos SRT/VTT.")
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(vm.candidates) { clip ->
                            Card {
                                Column(Modifier.padding(12.dp)) {
                                    Text("${formatTime(clip.startSeconds)} – ${formatTime(clip.endSeconds)}")
                                    Text("Puntuación: ${clip.score}/10")
                                    Text(clip.reason)
                                    Text("Título: ${clip.title}", style = MaterialTheme.typography.bodyMedium)
                                    Text(clip.hashtags.joinToString(" "), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatTime(seconds: Int): String =
    "%02d:%02d".format(seconds / 60, seconds % 60)
