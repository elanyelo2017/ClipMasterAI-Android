@echo off
setlocal
set "ROOT=%~dp0"
set "DEST=%ROOT%app\src\main\cpp\whisper.cpp"
if exist "%DEST%\.git" (
  echo whisper.cpp ya esta presente en: "%DEST%"
  exit /b 0
)
where git >nul 2>nul
if errorlevel 1 (
  echo ERROR: instala Git for Windows y vuelve a ejecutar este archivo.
  exit /b 1
)
git clone --depth 1 https://github.com/ggml-org/whisper.cpp.git "%DEST%"
if errorlevel 1 (
  echo ERROR: no se pudo descargar whisper.cpp.
  exit /b 1
)
echo whisper.cpp preparado. Abre esta carpeta en Android Studio e instala NDK y CMake 3.22.1.
endlocal
