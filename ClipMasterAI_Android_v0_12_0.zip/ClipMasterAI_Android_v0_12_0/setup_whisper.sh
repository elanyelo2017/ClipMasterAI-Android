#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
DEST="$ROOT/app/src/main/cpp/whisper.cpp"
if [ -d "$DEST/.git" ]; then
  echo "whisper.cpp ya está presente en: $DEST"
else
  git clone --depth 1 https://github.com/ggml-org/whisper.cpp.git "$DEST"
fi
echo "Fuente oficial lista. Abre la raíz del proyecto en Android Studio e instala NDK y CMake 3.22.1."
