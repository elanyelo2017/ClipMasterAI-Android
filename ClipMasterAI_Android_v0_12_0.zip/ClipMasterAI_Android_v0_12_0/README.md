# ClipMaster AI Android — v0.12.0

Proyecto fuente Kotlin + Jetpack Compose para Android 14 y dispositivos ARM64 como el OUKITEL G3. Objetivo: procesamiento local, gratuito y sin enviar video/audio a servidores.

## Novedades de v0.11
- Añadido puente JNI real para la API de whisper.cpp (`WhisperCppBridge`).
- Añadido `whisper_jni.cpp`: carga un modelo GGML local, lee WAV PCM mono 16 kHz/16 bits y devuelve segmentos con marcas de tiempo.
- Configurado CMake/NDK para ABI `arm64-v8a`, CPU-only y dos hilos para limitar carga en teléfonos modestos.
- Añadido en la pantalla el selector para importar `ggml-tiny.bin` y el botón **Transcribir y detectar 10 clips**.
- La transcripción se entrega al `ViralClipPlanner`; el análisis no inventa subtítulos cuando falta el motor/modelo.
- El modelo se copia al almacenamiento privado de la aplicación y queda disponible sin conexión después de importarlo.

## Preparar la dependencia nativa oficial

El código fuente de whisper.cpp no se redistribuye dentro de este ZIP. Desde la carpeta raíz del proyecto, ejecuta `./setup_whisper.sh` en Linux/macOS o haz doble clic en `setup_whisper.bat` en Windows (requiere Git instalado). Ambos scripts clonan el repositorio oficial `ggml-org/whisper.cpp` en `app/src/main/cpp/whisper.cpp`. Después abre el proyecto en Android Studio e instala Android NDK y CMake 3.22.1 desde SDK Manager.

## Modelo local

La primera vez, importa un modelo Whisper GGML compatible, por ejemplo `ggml-tiny.bin`, desde la pantalla de la aplicación. El modelo no viene incluido en el ZIP. Usa un modelo obtenido de una fuente oficial y revisa sus condiciones de licencia. La primera instalación requiere copiar el archivo al almacenamiento privado; después la inferencia es local y no requiere conexión.

`tiny` es el punto de partida recomendado para probar rendimiento y memoria. La velocidad depende del procesador, del códec, de la duración del video y de la memoria libre del teléfono. Para videos largos, conviene probar primero fragmentos cortos.

## Compilación

- Android Gradle Plugin del proyecto anfitrión, Kotlin y Compose según configuración Gradle.
- `compileSdk 35`, `minSdk 26`, `targetSdk 35`.
- NDK instalado desde Android Studio.
- CMake 3.22.1.
- ABI configurada: `arm64-v8a`.

Abre la carpeta raíz `ClipMasterAI_Android_v0_11_1` en Android Studio y ejecuta la tarea `assembleDebug` después de instalar whisper.cpp. El APK se generará en `app/build/outputs/apk/debug/` si la compilación termina correctamente.

## Flujo implementado
1. Seleccionar un video local al que tengas derecho de uso.
2. Importar el modelo GGML tiny una sola vez.
3. Pulsar **Transcribir y detectar 10 clips**.
4. La aplicación extrae audio a WAV mono PCM16/16 kHz con MediaCodec.
5. whisper.cpp realiza la transcripción en CPU, en español, sin nube.
6. Los segmentos temporizados pasan al detector heurístico `ViralClipPlanner`.

## Limitaciones conocidas
- El ZIP incluye el puente JNI y CMake, pero requiere clonar la dependencia upstream whisper.cpp antes de compilar.
- No se ha podido compilar aquí porque este entorno no incluye Android SDK/NDK ni el código upstream clonado. No se afirma que el APK esté listo.
- El detector viral sigue siendo heurístico basado en texto; no predice viralidad real.
- Los tiempos de Whisper se redondean a segundos en el planificador actual.
- La exportación vertical y la publicación en redes requieren pruebas e integración adicional. La publicación continúa siendo con aprobación manual.
- No se incluye descarga de videos de YouTube; importa archivos locales propios o autorizados.

## Privacidad
El audio y el video se procesan en el dispositivo. No se agregan endpoints de subida y el manifiesto no solicita el permiso INTERNET. La inferencia de audio y la detección se realizan localmente. La descarga inicial de dependencias para compilar y la obtención del modelo requieren conexión en el equipo de preparación; una vez instalados, el procesamiento puede hacerse sin conexión.

## Ajustes v0.12.0
- La pantalla separa el estado del modelo GGML del estado de la biblioteca JNI: importar el modelo ya no hace parecer que Whisper está listo si falta la biblioteca nativa.
- El botón de transcripción solo se activa cuando están disponibles tanto el modelo local como el motor Whisper ARM64.
- Se eliminó el permiso INTERNET del manifiesto: la aplicación no necesita permiso de red para el flujo local. La preparación del proyecto en un PC sí requiere internet para descargar dependencias y el código fuente de whisper.cpp.
- Se añadió `setup_whisper.bat` para preparar la dependencia desde Windows.

## Ajustes v0.11.1
- La capa JNI ya no carga el WAV completo en memoria: inspecciona el encabezado y lee ventanas de 30 segundos.
- Mantiene un único contexto Whisper durante toda la transcripción y suma el desplazamiento temporal a cada segmento.
- La pantalla indica el flujo real: importar video, instalar modelo y transcribir/detectar clips.
