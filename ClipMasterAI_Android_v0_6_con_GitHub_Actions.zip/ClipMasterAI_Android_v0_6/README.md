# ClipMaster AI Android — base v0.6.0

Proyecto fuente Android (Kotlin + Jetpack Compose), pensado para probarse en Android 14 / OUKITEL G3. El diseño busca procesamiento local y uso sin suscripción.

## Qué contiene realmente este ZIP
- Selección de un vídeo local mediante el selector de Android.
- Muestreo de fotogramas y detección de rostros con ML Kit.
- Exportación de un vídeo MP4 completo a formato vertical 9:16 con Media3.
- Exportador por lotes que acepta hasta 10 rangos de tiempo y crea un MP4 por rango.
- Una función básica que puntúa frases llamativas **solo si ya se le entrega una transcripción**.

## Lo que todavía NO está implementado
- No incluye un motor de reconocimiento de voz (ASR) ejecutable. `LocalTranscriptionEngine` es solo una interfaz/contrato.
- No obtiene automáticamente transcripciones del audio ni genera momentos virales por sí solo.
- No genera subtítulos sincronizados ni los incrusta en los vídeos.
- El análisis de rostros no está conectado al recorte dinámico de la exportación.
- No publica automáticamente en TikTok, YouTube, Facebook o Instagram.

Por tanto, el detector viral y los subtítulos automáticos aún no están terminados. No se debe considerar esta versión una aplicación lista para uso.

## Compilar APK usando GitHub (sin instalar Android Studio en el teléfono)
Este proyecto incluye `.github/workflows/android-apk.yml`. Después de subir los archivos del proyecto al repositorio GitHub:
1. Abre el repositorio en GitHub.
2. Entra en **Actions**.
3. Selecciona **Android APK**.
4. Pulsa **Run workflow** y confirma.
5. Si la compilación termina correctamente, abre la ejecución y descarga el artefacto `ClipMasterAI-debug-apk`.

El flujo intenta compilar un APK de depuración; no garantiza que compile hasta que GitHub Actions termine sin errores. El APK de depuración es para pruebas, no una versión firmada para publicar.

## Validación
El código no ha sido compilado ni probado en este entorno ni en un OUKITEL G3. La compilación de GitHub Actions será la primera verificación automatizada; después hay que instalar y probar el APK en el teléfono.
